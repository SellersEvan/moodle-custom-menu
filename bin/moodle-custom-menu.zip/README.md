# Moodle Custom Menu
Customize your moodle page navigation menu sidebar. This is designed to work only
for the Rose-Hulman moodle page, however you can fork this and update the `manifest.json` file to make it work for other moodle pages.